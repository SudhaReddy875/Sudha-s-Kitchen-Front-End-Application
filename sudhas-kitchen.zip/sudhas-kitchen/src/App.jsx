import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Menu from './pages/Menu';
import DishDetails from './pages/DishDetails';
import About from './pages/About';
import Services, { ServicesLayout, ServiceDetail } from './pages/Services';
import Reservations from './pages/Reservations';
import Contact from './pages/Contact';
import Profile from './pages/Profile';
import { RestaurantProvider } from './context/RestaurantContext';
export default function App() {
  return <RestaurantProvider><BrowserRouter><Routes><Route element={<Layout/>}><Route index element={<Home/>}/><Route path="menu" element={<Menu/>}/><Route path="menu/:id" element={<DishDetails/>}/><Route path="about" element={<About/>}/><Route path="services" element={<ServicesLayout/>}><Route index element={<Services/>}/><Route path="dine-in" element={<ServiceDetail type="dine-in"/>}/><Route path="takeaway" element={<ServiceDetail type="takeaway"/>}/><Route path="catering" element={<ServiceDetail type="catering"/>}/></Route><Route path="reservations" element={<Reservations/>}/><Route path="contact" element={<Contact/>}/><Route path="profile" element={<Profile/>}/><Route path="*" element={<Navigate to="/" replace/>}/></Route></Routes></BrowserRouter></RestaurantProvider>;
}
