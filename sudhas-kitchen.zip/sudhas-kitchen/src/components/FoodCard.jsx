import { useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { addToCart } from '../store/cartSlice';
export default function FoodCard({ item }) {
  const dispatch = useDispatch();
  return <article className="food-card"><Link to={`/menu/${item.id}`} className="food-image"><img src={item.image} alt={item.name} loading="lazy"/><span className="food-category">{item.category}</span></Link><div className="food-info"><div className="food-title-row"><h3><Link to={`/menu/${item.id}`}>{item.name}</Link></h3><strong>₹{item.price}</strong></div><p>{item.description}</p><div className="food-bottom"><span className="spice">🌶 {item.spice}</span><button className="button button-small" onClick={() => dispatch(addToCart(item))}>+ Add</button></div></div></article>;
}
