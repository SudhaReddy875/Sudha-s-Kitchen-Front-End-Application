import { createContext, useContext, useReducer } from 'react';
const RestaurantContext = createContext(null);
const initialState = { notice: 'Freshly prepared with authentic Andhra spices.' };
function noticeReducer(state, action) {
  switch (action.type) {
    case 'SET_NOTICE': return { ...state, notice: action.payload };
    case 'RESET_NOTICE': return initialState;
    default: return state;
  }
}
export function RestaurantProvider({ children }) {
  const [state, dispatch] = useReducer(noticeReducer, initialState);
  return <RestaurantContext.Provider value={{ state, dispatch }}>{children}</RestaurantContext.Provider>;
}
export function useRestaurant() {
  const context = useContext(RestaurantContext);
  if (!context) throw new Error('useRestaurant must be used inside RestaurantProvider');
  return context;
}
