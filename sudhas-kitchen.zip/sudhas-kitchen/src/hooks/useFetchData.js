import { useEffect, useState } from 'react';
export default function useFetchData(url) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        setLoading(true); setError('');
        const response = await fetch(url, { signal: controller.signal });
        if (!response.ok) throw new Error('Could not load data. Please try again later.');
        setData(await response.json());
      } catch (err) { if (err.name !== 'AbortError') setError(err.message || 'Something went wrong.'); }
      finally { if (!controller.signal.aborted) setLoading(false); }
    }
    load(); return () => controller.abort();
  }, [url]);
  return { data, loading, error };
}
