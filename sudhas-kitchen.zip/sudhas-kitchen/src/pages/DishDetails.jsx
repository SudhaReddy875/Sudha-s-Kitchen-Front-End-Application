import { Link, useParams } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { menuItems } from '../data/menu';
import { addToCart } from '../store/cartSlice';
export default function DishDetails() {
  const { id } = useParams(); const dispatch = useDispatch();
  const item = menuItems.find(entry => entry.id === Number(id));
  if (!item) return <section className="page-wrap empty-state"><h1>Dish not found</h1><p>That item may have moved off the menu.</p><Link className="button" to="/menu">Back to menu</Link></section>;
  return <section className="detail-layout page-wrap"><img className="detail-image" src={item.image} alt={item.name}/><div><span className="eyebrow">{item.category} · {item.spice}</span><h1>{item.name}</h1><p className="detail-description">{item.description}</p><div className="detail-price">₹{item.price}</div><p>Prepared fresh with a focus on bold regional flavours and traditional spice combinations.</p><button className="button" onClick={() => dispatch(addToCart(item))}>Add to your order ↗</button><p><Link className="text-link" to="/menu">← Back to menu</Link></p></div></section>;
}
