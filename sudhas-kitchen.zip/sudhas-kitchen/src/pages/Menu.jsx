import { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { menuItems } from '../data/menu';
import FoodCard from '../components/FoodCard';
const categories = ['All', ...new Set(menuItems.map(item => item.category))];
export default function Menu() {
  const [params, setParams] = useSearchParams();
  const search = params.get('search') || '';
  const category = params.get('category') || 'All';
  const page = Math.max(1, Number(params.get('page') || 1));
  const filtered = useMemo(() => menuItems.filter(item => (category === 'All' || item.category === category) && item.name.toLowerCase().includes(search.toLowerCase())), [category, search]);
  const pageSize = 6; const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));
  const update = values => setParams(current => { const next = new URLSearchParams(current); Object.entries(values).forEach(([key, value]) => value && value !== 'All' ? next.set(key, value) : next.delete(key)); return next; });
  return <section className="page-wrap"><div className="page-intro"><span className="eyebrow">GOOD FOOD, NO SHORTCUTS</span><h1>The <em>menu.</em></h1><p>Traditional favourites, honest ingredients and the bold flavours of Andhra.</p></div><div className="menu-tools"><input aria-label="Search dishes" placeholder="Search dishes…" value={search} onChange={e => update({ search: e.target.value, page: '' })}/><select aria-label="Filter by category" value={category} onChange={e => update({ category: e.target.value, page: '' })}>{categories.map(c => <option key={c}>{c}</option>)}</select></div><div className="food-grid">{filtered.slice((page - 1) * pageSize, page * pageSize).map(item => <FoodCard key={item.id} item={item}/>)}</div>{filtered.length === 0 && <div className="empty-state"><h3>No dishes found</h3><p>Try another dish name or choose a different category.</p><button className="button" onClick={() => setParams({})}>Clear filters</button></div>}<div className="pagination"><button className="button button-outline" disabled={page <= 1} onClick={() => update({ page: String(page - 1) })}>← Previous</button><span>Page {Math.min(page, pageCount)} of {pageCount}</span><button className="button button-outline" disabled={page >= pageCount} onClick={() => update({ page: String(page + 1) })}>Next →</button></div></section>;
}
